let productsCampoverde = [];

// Devuelve todos los productos
function getAllProducts(req, res) {
  res.json(productsCampoverde);
}

function createProduct(req,res){
  const { name, price } = req.body;
  if (!name || !price) {
    return res.status(400).json({ message: 'Name and price are required' });

  }
  const newProduct = { id: Date.now(), name, price };
  productsCampoverde.push(newProduct);
  res.status(201).json(newProduct);
}

// >Devuelve un  producto por ID 
function getProductForID (id){
   if (id===id.productsCampoverde){
    return id;
   }
}

// Eliminar un producto pór ID
function deleteProductForID() {

}




module.exports = { getAllProducts, createProduct, getProductForID,deleteProductForID, };
