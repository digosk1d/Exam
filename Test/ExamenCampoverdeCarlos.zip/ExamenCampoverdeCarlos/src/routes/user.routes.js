const express = require('express');
const { getAllProducts,  createProduct, getProductForID, deleteProductForID} = require('../controllers/user.controller');
const router = express.Router();
// Ruta GET para obtener todos los usuarios
router.get('/', getAllProducts);

// Ruta POST para agregar un nuevo producto
router.post('/',createProduct);

// Rut GET para devolver un producto por id 
router.get('/',getProductForID);

//Rute DELETE para eliminar un producto por id
router.delete('/',deleteProductForID);

//Ruta POST para crear un nuevo producto
//router.post('/', createProduct);

module.exports = router;