const express = require('express');
const userRoutes = require('./routes/user.routes');

const app = express();

app.use(express.json());
app.use('/api/productsCampoverde', userRoutes);


app.use((req, res) => {
  res.status(404).json({ error: 'Route Not Found' });
});
module.exports = app;