const request = require('supertest');
const app = require('../src/appCampoverdeCarlos');

describe('User API Tests', () => {
    test('GET /api/productsCampoverde devuelve todos los productos', async () => {
        const res = await request(app).get('/api/productsCampoverde');   
        expect(res.statusCode).toBe(200);
        expect(res.body).toEqual([]);
    });

    test('POST /api/productsCampoverde Agrega un producto', async () => {
        const newProduct = { name: 'Laptop', price: '1000' };
        const res = await request(app).post('/api/productsCampoverde').send(newProduct);
        expect(res.statusCode).toBe(201); 
        expect(res.body).toHaveProperty('id');
        expect(res.body.name).toBe('Laptop');
        expect(res.body.price).toBe('1000');
    });
    test('GET /api/productsCampoverde devuelve un producto por ID', async () => {
        
        
    });


    test('DELETE /api/productsCampoverde Elimina un producto pór ID', async () => {

    });


    test('POST /api/productsCampoverde Agrega un producto', async () => {
        const newProduct = { name: 'Mouse', price: '600' };
        const res = await request(app).post('/api/productsCampoverde').send(newProduct);
        expect(res.statusCode).toBe(201); 
        expect(res.body).toHaveProperty('id');
        expect(res.body.name).toBe('Mouse');
        expect(res.body.price).toBe('600');
    });

    test('POST /api/productsCampoverde Agrega un producto', async () => {
        const newProduct = { name: 'Cellphone', price: '550' };
        const res = await request(app).post('/api/productsCampoverde').send(newProduct);
        expect(res.statusCode).toBe(201); 
        expect(res.body).toHaveProperty('id');
        expect(res.body.name).toBe('Cellphone');
        expect(res.body.price).toBe('550');
    });

    
    
});

